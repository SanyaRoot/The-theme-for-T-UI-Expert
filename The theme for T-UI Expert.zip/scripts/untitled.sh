#!/bin/sh

T=0
while [[ "$T" -lt $2 ]]; do
	echo "Инфа о процессе" >> file.txt
	T=$(($T+1))
	sleep 1
done



 sleep 1
echo Загрузка...
 sleep 2
echo □□□□□ 0%
 sleep 3
echo ■□□□□ 20%
 sleep 4
echo ■■□□□ 40%
 sleep 5
echo ■■■□□ 60%
 sleep 6
echo ■■■■□ 80%
 sleep 7
echo ■■■■■ 100%
 sleep 8
echo Распаковка...
 sleep 9
echo Чтения...
 sleep 10
echo Sanya Root

 
echo"Внешний IP"
curl ipecho.net/plain 
